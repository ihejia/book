# file2

source: `{{ page.path }}`
