---
sort: 1
---

# Installation

There are two ways to install:

{% include list.liquid %}
