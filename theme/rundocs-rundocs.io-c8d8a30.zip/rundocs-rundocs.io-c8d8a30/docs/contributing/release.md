---
sort: 5
---

# Release theme

Change both version in following files:

```
jekyll-rtd-theme.gemspec

_includes/reset/defaults.liquid
```
