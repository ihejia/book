---
sort: 5
---

# Set up analysis related

```yml
google:
  gtag: # gtag code
  adsense: # adsense code
```
