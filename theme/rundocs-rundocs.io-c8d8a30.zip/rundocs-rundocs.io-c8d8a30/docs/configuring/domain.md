---
sort: 14
---

# Custom your docs domain
Free domain name is `*.rundocs.io`, now avaiable!

## why?
- Better SEO supported(cloudflare)
- Better establish brand image
- No deployment required
- Just pull a request to use the domain!

For details, see : [https://github.com/rundocs/rundocs.io/blob/master/ns.js](https://github.com/rundocs/rundocs.io/blob/master/ns.js)
