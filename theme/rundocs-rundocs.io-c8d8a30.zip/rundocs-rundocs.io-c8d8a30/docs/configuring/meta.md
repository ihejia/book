---
sort: 6
---

# Set up meta data

```yml
meta:
  key1: value1
  key2: value2
  key3: value3
  key4: value4
  .
  .
  .
```
