module.exports = {
    cname: {
        "rundocs.io": "rundocs.github.io",
        /* start */
        "jekyll-theme-docsify": "rundocs.github.io",
        "jekyll-rtd-theme": "rundocs.github.io",
    },
    txt: {
        "rundocs.io": "google-site-verification=X-KVlK1E2ZRkqgO3UzHYn4Fm26gUlZY132HREO4lkmM",
    }
}
