---
sort: 5
---

# Emoji Test

```
I give this theme two :+1:!
```

I give this theme two :+1:!

```tip
Set config `plugins: [jemoji]`, Emoji searcher, see: [https://emoji.muan.co/](https://emoji.muan.co/)
```
